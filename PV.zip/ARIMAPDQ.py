import warnings
import itertools
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf,plot_pacf
from statsmodels.tsa.arima_model import ARIMA
import pmdarima as pm
from pmdarima.arima.utils import ndiffs
# import data
df = pd.read_csv('F:\\2019 Fall data science\\cpts 575-20191106T054620Z-001\\'
                 'cpts 575\\solar_data-2018.csv', usecols=['InvPDC_kW_Avg'])
df1 = df.fillna(0)
df2 = df1[df1['InvPDC_kW_Avg']>=0]

# 3,0,3 ARIMA Model
model = ARIMA(df2['InvPDC_kW_Avg'], order=(3,0,3))
model_fit = model.fit(disp= -1)
print(model_fit.summary())

# Plot residual errors
residuals = pd.DataFrame(model_fit.resid)
fig, ax = plt.subplots(1,2)
residuals.plot(title="Residuals", ax=ax[0])
residuals.plot(kind='kde', title='Density', ax=ax[1])
plt.show()
#
# Actual vs Fitted
model_fit.plot_predict(dynamic=False)
plt.show()
# print("Accuracy:" + "97."